# Test a Moodle Instance

## Prerequisites

It is obviously necessary to have a [Moodle cluster up and running](./Deploy.md).

## Next Steps

  * [Delete all Resources](./Delete.md)
